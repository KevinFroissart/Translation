<!doctype html>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->

<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->

<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->

<!--[if gt IE 8]><!--><html class="no-js" lang="en"><!--<![endif]-->

<head>

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<title></title>

<meta name="description" content="">

<meta name="keywords" content="">

</head>



<body>

<div >

    <h1 style="font-size: 1.875rem;font-weight: 700;margin-bottom: 15px;">Recharges à prix réduit disponibles</h1>

    <div style="font-size: 1.2rem;margin-bottom: 10px;">

   Économisez 15% maintenant et jusqu'à 40% sur les futures livraisons.

    Avec un abonnement, vous recevrez vos produits CBD préférés mensuellement avec 40% de réduction sur le prix d'origine! Automatiquement, sans souci et avec la même garantie de remboursement.



    </div>

    <div style="font-size: 1.1rem;margin-bottom: 10px;">

        Aucune obligation à long terme. Annulez, suspendez ou ajustez votre commande à tout moment, sans tracas. Votre carte de crédit ne sera débitée que lorsque votre commande sera expédiée.

    </div>

</div>

</body>

</html>